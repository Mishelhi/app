import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    ChangeNotifierProvider(
      create: (context) => FireBaseState(),
      child: App(),
    ),
  );
}

class App extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  App({super.key});
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
              body: Center(
                  child: Text(snapshot.error.toString(),
                      textDirection: TextDirection.ltr)));
        }
        if (snapshot.connectionState == ConnectionState.done) {
          return const MyApp();
        }
        return const Center(child: CircularProgressIndicator());
      },
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
        create: (ctx) => FireBaseState(),
        child: MaterialApp(
          title: 'Startup Name Generator',
          theme: ThemeData(
            appBarTheme: const AppBarTheme(
              backgroundColor: Colors.white,
              foregroundColor: Colors.black,
            ),
          ),
          home: const RandomWords(),
        ));
  }
}

class RandomWords extends StatefulWidget {
  const RandomWords({super.key});

  @override
  State<RandomWords> createState() => _RandomWordsState();
}

class _RandomWordsState extends State<RandomWords> {
  final _biggerFont = const TextStyle(fontSize: 18);
  bool isLoading = false;
  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          )
        : Scaffold(
            appBar: AppBar(
              backgroundColor: Colors.deepPurple,
              foregroundColor: Colors.white,
              title: const Text('Startup Name Generator'),
              actions: [
                IconButton(
                  icon: const Icon(Icons.list),
                  onPressed: _pushSaved,
                  tooltip: 'Saved Suggestions',
                ),
                if (Provider.of<FireBaseState>(context).loginStatus ==
                    Status.authenticated)
                  IconButton(
                    icon: const Icon(Icons.exit_to_app),
                    onPressed: () async {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('Successfully logged out')),
                      );
                      Provider.of<FireBaseState>(context, listen: false)
                          .signOut();
                    },
                  ),
                if (Provider.of<FireBaseState>(context).loginStatus ==
                    Status.unauthenticated)
                  IconButton(
                    icon: const Icon(Icons.login),
                    tooltip: 'Login',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const LoginScreen()),
                      ).then((_) async {
                        if (Provider.of<FireBaseState>(context, listen: false)
                                .loginStatus ==
                            Status.authenticated) {
                          setState(() {
                            isLoading = false;
                          });
                        }
                      });
                    },
                  ),
              ],
            ),
            body: ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemBuilder: (context, i) {
                if (i.isOdd) return const Divider();
                final index = i ~/ 2;
                if (index >=
                    Provider.of<FireBaseState>(context, listen: false)
                        .suggestions
                        .length) {
                  Provider.of<FireBaseState>(context, listen: false)
                      .suggestions
                      .addAll(generateWordPairs().take(10));
                }
                var word = Provider.of<FireBaseState>(context, listen: false)
                    .suggestions[index];
                final alreadySaved =
                    Provider.of<FireBaseState>(context, listen: false)
                        .saved
                        .contains(word);
                return ListTile(
                  title: Text(
                    word.asPascalCase,
                    style: _biggerFont,
                  ),
                  trailing: Icon(
                    alreadySaved ? Icons.star : Icons.star_border,
                    color: alreadySaved ? Colors.red : null,
                    semanticLabel: alreadySaved ? 'Remove from saved' : 'Save',
                  ),
                  onTap: () {
                    setState(() {
                      var word =
                          Provider.of<FireBaseState>(context, listen: false)
                              .suggestions[index];
                      if (alreadySaved) {
                        Provider.of<FireBaseState>(context, listen: false)
                            .remove(word);
                        Provider.of<FireBaseState>(context, listen: false)
                            .deleteSuggestion(word);
                      } else {
                        Provider.of<FireBaseState>(context, listen: false)
                            .add(word);
                        Provider.of<FireBaseState>(context, listen: false)
                            .saveSuggestion(word);
                      }
                    });
                  },
                );
              },
            ),
          );
  }

  void _pushSaved() {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (context) {
          final tiles = Provider.of<FireBaseState>(context, listen: false)
              .saved
              .map(
                (pair) => Dismissible(
                  key: Key(pair.asPascalCase),
                  confirmDismiss: (direction) async {
                    return await showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: const Text('Delete Suggestion'),
                              content: Text(
                                  'Are you sure you want to delete ${pair.asPascalCase} from your saved suggestions?'),
                              actions: <Widget>[
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.deepPurple,
                                    borderRadius: BorderRadius.circular(4.0),
                                  ),
                                  child: TextButton(
                                    child: const Text('No',
                                        style: TextStyle(color: Colors.white)),
                                    onPressed: () {
                                      Navigator.of(context).pop(false);
                                    },
                                  ),
                                ),
                                Container(
                                    decoration: BoxDecoration(
                                      color: Colors.deepPurple,
                                      borderRadius: BorderRadius.circular(4.0),
                                    ),
                                    child: TextButton(
                                      child: const Text('Yes',
                                          style:
                                              TextStyle(color: Colors.white)),
                                      onPressed: () {
                                        Navigator.of(context).pop(true);
                                      },
                                    ))
                              ],
                            );
                          },
                        ) ??
                        false;
                  },
                  onDismissed: (direction) {
                    setState(() {
                      Provider.of<FireBaseState>(context, listen: false)
                          .remove(pair);
                      Provider.of<FireBaseState>(context, listen: false)
                          .deleteSuggestion(pair);
                    });
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('${pair.asPascalCase} deleted'),
                      ),
                    );
                  },
                  background: Container(
                    color: Colors.deepPurple,
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        SizedBox(width: 20),
                        Icon(Icons.delete, color: Colors.white),
                        Text(" Delete Suggestion",
                            style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                  child: ListTile(
                    title: Text(
                      pair.asPascalCase,
                      style: _biggerFont,
                    ),
                  ),
                ),
              );
          final divided = tiles.isNotEmpty
              ? ListTile.divideTiles(context: context, tiles: tiles).toList()
              : <Widget>[];
          return Scaffold(
            appBar: AppBar(
              title: const Text('Saved Suggestions'),
              backgroundColor: Colors.deepPurple,
              foregroundColor: Colors.white,
            ),
            body: ListView(children: divided),
          );
        },
      ),
    );
  }
}

enum Status {
  authenticating,
  authenticated,
  unauthenticated,
}

class FireBaseState extends ChangeNotifier {
  final _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  Status _loginStatus = Status.unauthenticated;
  Status _signupStatus = Status.unauthenticated;

  Status get loginStatus => _loginStatus;
  Status get signupStatus => _signupStatus;
  UserCredential? _user;
  final Set<WordPair> _saved = <WordPair>{};
  final _suggestions = <WordPair>[];
  Set<WordPair> get saved => _saved;
  List<WordPair> get suggestions => _suggestions;

  void add(WordPair pair) {
    _saved.add(pair);
    notifyListeners();
  }

  void remove(WordPair pair) {
    _saved.remove(pair);
    notifyListeners();
  }

  Future<void> signOut() async {
    _loginStatus = Status.unauthenticated;
    _user = null;
    notifyListeners();
    await _auth.signOut();
  }

  Future<void> signup(
      String email, String password, BuildContext context) async {
    _signupStatus = Status.authenticating;
    notifyListeners();
    try {
      // Create a new user
      _user = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      _signupStatus = Status.authenticated;
      _loginStatus = Status.authenticated;
      notifyListeners();
      Navigator.pop(context);
    } catch (e) {
      _signupStatus = Status.unauthenticated;
      notifyListeners();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('There was an error Sigening up to into the app')));
    } finally {}
  }

  Future<void> login(
      String email, String password, BuildContext context) async {
    _loginStatus = Status.authenticating;
    notifyListeners();
    try {
      // Authenticate with Firebase
      _user = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      for (var suggestion in _saved) {
        await saveSuggestion(suggestion);
      }
      Set<WordPair> remoteSaved = await fetchSavedSuggestions();
      _saved.addAll(remoteSaved);
      _suggestions.insertAll(
          0,
          remoteSaved
              .toList()
              .where((element) => !_suggestions.contains(element)));
      _loginStatus = Status.authenticated;
      notifyListeners();
      Navigator.pop(context);
      // User is logged in
      // You can access user info with userCredential.user
    } catch (e) {
      _loginStatus = Status.unauthenticated;
      notifyListeners();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('There was an error logging into the app')));
    } finally {}
  }

  WordPair stringToWordPair(String wordPairString) {
    // Split the string into words
    List<String> words = wordPairString.split(RegExp(r"(?=[A-Z])"));

    // Create a new WordPair from the words
    WordPair wordPair =
        WordPair(words[0].toLowerCase(), words[1].toLowerCase());

    return wordPair;
  }

  Future<void> saveSuggestion(WordPair suggestion) async {
    if (_user != null) {
      if (await isSuggestionSaved(suggestion)) {
        return;
      }
      await _firestore
          .collection('users')
          .doc(_user!.user!.uid)
          .collection('suggestions')
          .add({'suggestion': suggestion.asPascalCase});
    }
    notifyListeners();
  }

  Future<bool> isSuggestionSaved(WordPair suggestion) async {
    final snapshot = await _firestore
        .collection('users')
        .doc(_user!.user!.uid)
        .collection('suggestions')
        .where('suggestion', isEqualTo: suggestion.asPascalCase)
        .get();

    return snapshot.docs.isNotEmpty;
  }

  Future<void> deleteSuggestion(WordPair suggestion) async {
    if (_user != null) {
      final snapshot = await _firestore
          .collection('users')
          .doc(_user!.user!.uid)
          .collection('suggestions')
          .where('suggestion', isEqualTo: suggestion.asPascalCase)
          .get();
      if (snapshot.docs.isNotEmpty) {
        await _firestore
            .collection('users')
            .doc(_user!.user!.uid)
            .collection('suggestions')
            .doc(snapshot.docs.first.id)
            .delete();
      }
    }
    notifyListeners();
  }

  Future<Set<WordPair>> fetchSavedSuggestions() async {
    final snapshot = await _firestore
        .collection('users')
        .doc(_user!.user!.uid)
        .collection('suggestions')
        .get();
    return snapshot.docs
        .map((doc) => doc.data()['suggestion'] as String?)
        .where((suggestion) => suggestion != null)
        .map((e) => stringToWordPair(e!))
        .toSet();
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          child: Column(
            children: <Widget>[
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(
                  hintText: 'Enter your email',
                  labelText: 'Email',
                ),
              ),
              TextFormField(
                controller: _passwordController,
                decoration: const InputDecoration(
                  hintText: 'Enter your password',
                  labelText: 'Password',
                ),
              ),
              Column(
                children: <Widget>[
                  const SizedBox(height: 7),
                  SizedBox(
                    width: 100.0,
                    height: 30.0,
                    child: ElevatedButton(
                      onPressed: Provider.of<FireBaseState>(context)
                                  .loginStatus ==
                              Status.authenticating
                          ? null
                          : () {
                              String email = _emailController.text;
                              String password = _passwordController.text;
                              Provider.of<FireBaseState>(context, listen: false)
                                  .login(email, password, context);
                            },
                      child: Provider.of<FireBaseState>(context).loginStatus ==
                              Status.authenticating
                          ? const CircularProgressIndicator()
                          : const Text('Login'),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: 100.0,
                    height: 30.0,
                    child: ElevatedButton(
                      onPressed: Provider.of<FireBaseState>(context)
                                  .signupStatus ==
                              Status.authenticating
                          ? null
                          : () {
                              String email = _emailController.text;
                              String password = _passwordController.text;
                              Provider.of<FireBaseState>(context, listen: false)
                                  .signup(email, password, context);
                            },
                      child: Provider.of<FireBaseState>(context).signupStatus ==
                              Status.authenticating
                          ? const CircularProgressIndicator()
                          : const Text('Sign Up'),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
